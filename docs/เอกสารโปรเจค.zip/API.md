# API Reference

> Base URL (ผ่าน API Gateway): `http://localhost:8080`

---

## Authentication Endpoints

### Register
```http
POST /api/auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "Password1234!",
  "name": "John Doe"
}
```

**Response 201:**
```json
{
  "message": "Registration successful",
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "name": "John Doe",
    "role": "USER"
  }
}
```

---

### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "Password1234!"
}
```

**Response 200:**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiJ9...",
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "name": "John Doe",
    "role": "USER"
  }
}
```
*refresh_token ส่งผ่าน httpOnly cookie*

---

### Logout
```http
POST /api/auth/logout
Authorization: Bearer <access_token>
```

**Response 200:**
```json
{ "message": "Logged out successfully" }
```

---

### Refresh Token
```http
POST /api/auth/refresh
Cookie: refresh_token=<token>
```

**Response 200:**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiJ9..."
}
```

---

### Get Current User
```http
GET /api/auth/me
Authorization: Bearer <access_token>
```

**Response 200:**
```json
{
  "id": "uuid",
  "email": "user@example.com",
  "name": "John Doe",
  "role": "USER"
}
```

---

## Catalog Endpoints

### List Products
```http
GET /api/catalog/products?page=1&limit=20&categoryId=uuid&search=keyword
```

**Response 200:**
```json
{
  "data": [
    {
      "id": "uuid",
      "name": "Product Name",
      "description": "...",
      "price": 299.00,
      "stockQuantity": 50,
      "category": { "id": "uuid", "name": "Electronics" }
    }
  ],
  "pagination": { "page": 1, "limit": 20, "total": 100 }
}
```

---

### Get Product
```http
GET /api/catalog/products/:id
```

---

### Create Product `[ADMIN]`
```http
POST /api/catalog/products
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "name": "New Product",
  "description": "Description",
  "price": 199.00,
  "stockQuantity": 100,
  "categoryId": "uuid"
}
```

---

### Update Product `[ADMIN]`
```http
PUT /api/catalog/products/:id
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "name": "Updated Name",
  "price": 249.00
}
```

---

### Delete Product `[ADMIN]`
```http
DELETE /api/catalog/products/:id
Authorization: Bearer <admin_token>
```

---

### Adjust Stock `[ADMIN]`
```http
PATCH /api/catalog/products/:id/stock
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "quantity": 50,
  "type": "ADD",
  "reason": "Restock from supplier"
}
```

`type` รับค่า: `ADD` | `SUBTRACT`

---

### List Categories
```http
GET /api/catalog/categories
```

---

### Create Category `[ADMIN]`
```http
POST /api/catalog/categories
Authorization: Bearer <admin_token>
Content-Type: application/json

{ "name": "Electronics", "description": "..." }
```

---

### Update Category `[ADMIN]`
```http
PUT /api/catalog/categories/:id
Authorization: Bearer <admin_token>
Content-Type: application/json

{ "name": "Updated Category" }
```

---

### Delete Category `[ADMIN]`
```http
DELETE /api/catalog/categories/:id
Authorization: Bearer <admin_token>
```

---

## Order Endpoints

### Place Order `[USER]`
```http
POST /api/orders
Authorization: Bearer <user_token>
Content-Type: application/json

{
  "items": [
    { "productId": "uuid", "quantity": 2 },
    { "productId": "uuid", "quantity": 1 }
  ],
  "shippingAddress": "123 Main St, Bangkok"
}
```

**Response 201:**
```json
{
  "id": "uuid",
  "status": "CONFIRMED",
  "totalAmount": 597.00,
  "items": [...],
  "createdAt": "2026-06-04T10:00:00Z"
}
```

**Response 400 (stock ไม่พอ):**
```json
{
  "error": "Insufficient stock",
  "details": [{ "productId": "uuid", "requested": 5, "available": 2 }]
}
```

---

### My Orders `[USER]`
```http
GET /api/orders/me?page=1&limit=10
Authorization: Bearer <user_token>
```

**Response 200:**
```json
{
  "data": [
    {
      "id": "uuid",
      "status": "CONFIRMED",
      "totalAmount": 597.00,
      "items": [...],
      "createdAt": "2026-06-04T10:00:00Z"
    }
  ],
  "pagination": { "page": 1, "limit": 10, "total": 5 }
}
```

---

### Get Order by ID `[USER / ADMIN]`
```http
GET /api/orders/:id
Authorization: Bearer <token>
```

---

### All Orders `[ADMIN]`
```http
GET /api/orders?page=1&limit=20&status=CONFIRMED
Authorization: Bearer <admin_token>
```

---

## Error Response Format

ทุก error response มีรูปแบบ:

```json
{
  "error": "Error type",
  "message": "Human-readable message",
  "statusCode": 400
}
```

| Status Code | ความหมาย |
|---|---|
| 400 | Bad Request — ข้อมูลไม่ถูกต้อง |
| 401 | Unauthorized — ไม่มี token หรือ token ไม่ valid |
| 403 | Forbidden — ไม่มีสิทธิ์ |
| 404 | Not Found |
| 409 | Conflict — เช่น email ซ้ำ |
| 500 | Internal Server Error |

---

## API Gateway Routes (Nginx)

```nginx
location /api/auth/     → http://auth-service:3001
location /api/catalog/  → http://catalog-service:3002
location /api/orders/   → http://order-service:3003
location /              → http://frontend:5173
```
