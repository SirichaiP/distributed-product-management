# Security Documentation

## JWT Strategy

### Token Types

| Token | Algorithm | TTL | Storage | หน้าที่ |
|---|---|---|---|---|
| Access Token | HS256 | 15 นาที | Memory (React state) | Authorization header |
| Refresh Token | HS256 | 7 วัน | httpOnly Cookie | ต่ออายุ access token |

### Access Token Payload
```json
{
  "userId": "uuid",
  "email": "user@example.com",
  "role": "USER",
  "iat": 1749024000,
  "exp": 1749024900
}
```

### เหตุผลของ TTL ที่เลือก
- **Access token 15 นาที**: สั้นพอที่จะจำกัดความเสียหายหาก token ถูก compromise แต่ไม่สั้นเกินไปจน UX แย่
- **Refresh token 7 วัน**: ทำให้ user ไม่ต้อง login ทุกวัน, Refresh token rotation ลดความเสี่ยง

### Refresh Token Rotation
ทุกครั้งที่มีการ refresh:
1. Verify refresh token ปัจจุบัน
2. Mark refresh token ปัจจุบันว่า `revoked = true`
3. ออก refresh token ใหม่
4. ออก access token ใหม่

ทำให้ถ้า refresh token ถูกขโมย และ attacker ใช้ก่อน จะ invalidate session ของ real user ทำให้ตรวจพบการโจมตีได้

---

## Role-Based Authorization

### Roles

| Role | ระดับ | สิทธิ์ |
|---|---|---|
| `ADMIN` | สูงสุด | จัดการ product, category, stock, ดู orders ทั้งหมด |
| `USER` | ปกติ | ดู product, สั่งซื้อ, ดู orders ของตัวเอง |

### Authorization Middleware Flow

```
Request → JWT Middleware (verify signature) → Role Guard (check role) → Route Handler
```

**JWT Middleware** (ทุก protected route):
```
1. Extract Bearer token จาก Authorization header
2. Verify signature ด้วย JWT_ACCESS_SECRET
3. ตรวจ expiry (exp)
4. Inject user data เข้า request context
```

**Role Guard** (routes ที่ต้องการ role เฉพาะ):
```
1. อ่าน role จาก request context (set โดย JWT Middleware)
2. เปรียบเทียบกับ required role
3. Return 403 ถ้าไม่ตรง
```

---

## API Gateway Security

### Request Filtering (Nginx)
- Internal endpoints (`/internal/*`) ไม่ถูก expose ออก gateway
- Service-to-service communication ผ่าน Docker network เท่านั้น

```nginx
# ซ่อน internal endpoints จาก public
location /internal/ {
  deny all;
  return 404;
}
```

### CORS Configuration
- Origin ที่อนุญาต: `http://localhost:5173` (development)
- Production ต้องกำหนด origin จริง

---

## Service Authorization

### Inter-Service Authentication
- Order Service → Catalog Service: ใช้ internal Docker network, ไม่ต้องผ่าน JWT
- Auth Service expose `/api/auth/verify` สำหรับ validate token แต่ services อื่นใช้ local verification แทน (ประสิทธิภาพดีกว่า)

---

## Password Security

- Hash ด้วย **bcrypt** (cost factor 12)
- ไม่เก็บ plain text password
- Password validation: อย่างน้อย 8 ตัวอักษร, มีตัวพิมพ์ใหญ่, ตัวพิมพ์เล็ก, ตัวเลข

---

## Known Security Risks & Improvements

| ความเสี่ยง | ระดับ | การแก้ไขที่แนะนำ |
|---|---|---|
| Access token ไม่สามารถ revoke ได้ทันที | Medium | เพิ่ม Redis token blacklist |
| Secrets ใน .env ไม่ rotate | Medium | ใช้ Secret Manager (Vault/AWS SSM) |
| ไม่มี rate limiting ที่ login endpoint | High | เพิ่ม nginx rate limit หรือ middleware |
| JWT secret เดียวกันทุก service | Low | ใช้ asymmetric keys (RS256) แทน |
| ไม่มี audit log สำหรับ admin actions | Medium | เพิ่ม audit_log table |

---

## Security Checklist ก่อน Production

- [ ] เปลี่ยน JWT secrets เป็นค่า random ที่แข็งแกร่ง (≥ 32 bytes)
- [ ] ตั้ง HTTPS/TLS ที่ Nginx
- [ ] จำกัด CORS origin เป็น domain จริง
- [ ] เพิ่ม rate limiting ที่ auth endpoints
- [ ] ตรวจสอบว่าไม่มี secret หลุดใน Git history
- [ ] เพิ่ม security headers (X-Content-Type-Options, X-Frame-Options)
