# Order & Stock Flow

## Overview

ระบบจัดการ order และ stock ผ่าน 2 ช่องทางหลัก:
- **Synchronous HTTP** — สำหรับ check stock ก่อน place order (ต้องการ response ทันที)
- **Asynchronous RabbitMQ** — สำหรับ deduct / release stock หลัง order confirmed

---

## Place Order Flow (Successful)

```mermaid
sequenceDiagram
    actor User
    participant GW as API Gateway
    participant OS as Order Service
    participant CS as Catalog Service
    participant MQ as RabbitMQ
    participant OSDB as Order DB
    participant CSDB as Catalog DB

    User->>GW: POST /api/orders { items: [...] }
    GW->>OS: Forward + validate JWT

    loop แต่ละ item ใน order
        OS->>CS: GET /internal/stock/:productId
        CS->>CSDB: Query stock
        CSDB-->>CS: { quantity: 50 }
        CS-->>OS: { available: 50 }
    end

    OS->>OS: ตรวจสอบว่า stock ทุก item เพียงพอ

    OS->>OSDB: INSERT order (status: CONFIRMED)
    OS->>MQ: Publish "catalog.stock.deduct"<br/>{ items: [{ productId, quantity }] }

    MQ->>CS: Consume event
    CS->>CSDB: UPDATE stock (quantity - deducted)

    OS-->>GW: 201 Created { orderId, status: "CONFIRMED" }
    GW-->>User: 201 Created
```

---

## Place Order Flow (Failed — Stock ไม่พอ)

```mermaid
sequenceDiagram
    actor User
    participant OS as Order Service
    participant CS as Catalog Service

    User->>OS: POST /api/orders { items: [{ productId, quantity: 100 }] }

    OS->>CS: GET /internal/stock/:productId
    CS-->>OS: { available: 5 }

    OS->>OS: quantity(100) > available(5) → FAIL

    OS-->>User: 400 Bad Request<br/>{ error: "Insufficient stock",<br/>  details: [{ productId, requested: 100, available: 5 }] }
```

---

## Stock Release Flow (Order Cancelled)

```mermaid
sequenceDiagram
    actor Admin
    participant OS as Order Service
    participant MQ as RabbitMQ
    participant CS as Catalog Service

    Admin->>OS: PATCH /api/orders/:id/cancel
    OS->>OS: ตรวจสอบว่า order ยังอยู่ใน state ที่ cancel ได้
    OS->>OS: UPDATE order status → CANCELLED
    OS->>MQ: Publish "catalog.stock.release"<br/>{ items: [{ productId, quantity }] }

    MQ->>CS: Consume event
    CS->>CS: UPDATE stock (quantity + released)
```

---

## Admin Stock Adjustment Flow

```mermaid
sequenceDiagram
    actor Admin
    participant GW as API Gateway
    participant CS as Catalog Service
    participant CSDB as Catalog DB

    Admin->>GW: PATCH /api/catalog/products/:id/stock<br/>{ quantity: 50, type: "ADD" }
    GW->>CS: Forward + validate ADMIN role

    CS->>CSDB: UPDATE products SET stock_quantity = stock_quantity + 50
    CS->>CSDB: INSERT stock_adjustments (audit log)

    CS-->>Admin: 200 OK { newQuantity: 150 }
```

---

## RabbitMQ Events

### `catalog.stock.deduct`
```json
{
  "eventType": "STOCK_DEDUCT",
  "orderId": "uuid",
  "items": [
    { "productId": "uuid", "quantity": 2 },
    { "productId": "uuid", "quantity": 1 }
  ],
  "timestamp": "2026-06-04T10:00:00Z"
}
```

### `catalog.stock.release`
```json
{
  "eventType": "STOCK_RELEASE",
  "orderId": "uuid",
  "items": [
    { "productId": "uuid", "quantity": 2 }
  ],
  "timestamp": "2026-06-04T10:00:00Z"
}
```

---

## Order Status Lifecycle

```
PENDING → CONFIRMED → SHIPPED → DELIVERED
                   ↘ CANCELLED
```

| Status | ความหมาย | Stock Action |
|---|---|---|
| `PENDING` | รอ payment / confirmation | Stock check ผ่านแล้ว แต่ยังไม่ตัด |
| `CONFIRMED` | ยืนยันแล้ว | Stock ถูกตัดผ่าน RabbitMQ |
| `CANCELLED` | ยกเลิก | Stock ถูกคืนผ่าน RabbitMQ |
| `SHIPPED` | จัดส่งแล้ว | ไม่เปลี่ยน stock |
| `DELIVERED` | ส่งถึงแล้ว | ไม่เปลี่ยน stock |

---

## Edge Cases

### 1. Catalog Service ล่มขณะ Order Service ส่ง event
- RabbitMQ เก็บ message ไว้ใน durable queue
- เมื่อ Catalog Service กลับมา online จะ consume message ที่ค้างอยู่
- Order status ยังคงเป็น `CONFIRMED` แต่ stock จะถูกตัดในภายหลัง

### 2. Race condition — สอง User สั่งสินค้าชิ้นสุดท้ายพร้อมกัน
- ทั้งสอง Order ผ่าน stock check (synchronous) ได้เพราะ stock ยังมีอยู่
- Catalog Service ใช้ `UPDATE ... WHERE stock_quantity >= quantity` เพื่อป้องกัน negative stock
- หากเกิด conflict: second update จะ fail → Catalog Service ส่ง `stock.deduct.failed` event กลับ → Order Service update status เป็น `FAILED`

### 3. ผู้ใช้สั่ง quantity = 0 หรือลบ
- Validation layer ที่ Order Service reject ก่อน (HTTP 400)

### 4. สินค้าถูกลบขณะมี order ค้างอยู่
- Order เก็บ snapshot ของ product name และ price ณ เวลาที่สั่ง
- Product deletion ไม่กระทบ historical orders
