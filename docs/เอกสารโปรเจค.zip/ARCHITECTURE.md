# Architecture Documentation

## High-Level Architecture

ระบบ Distributed Product Management System ออกแบบตาม **Microservices Architecture** โดยแต่ละ service มีความรับผิดชอบที่ชัดเจน แยก database เป็นของตัวเอง และสื่อสารกันผ่านทั้ง synchronous HTTP และ asynchronous message queue (RabbitMQ)

```mermaid
graph TB
    Browser[React SPA<br/>Frontend] -->|HTTP| Gateway

    subgraph Gateway Layer
        Gateway[Nginx API Gateway<br/>:8080]
    end

    Gateway -->|/api/auth/*| AuthSvc
    Gateway -->|/api/catalog/*| CatalogSvc
    Gateway -->|/api/orders/*| OrderSvc

    subgraph Services
        AuthSvc[Auth Service<br/>Node.js + TypeScript<br/>:3001]
        CatalogSvc[Catalog Service<br/>.NET 10 + C#<br/>:3002]
        OrderSvc[Order Service<br/>Node.js + TypeScript<br/>:3003]
    end

    OrderSvc -->|HTTP - validate JWT| AuthSvc
    OrderSvc -->|HTTP - check stock| CatalogSvc
    OrderSvc -->|Publish: stock.deduct| MQ
    MQ -->|Subscribe: stock.deduct| CatalogSvc

    AuthSvc --> AuthDB[(PostgreSQL<br/>auth_db)]
    CatalogSvc --> CatalogDB[(PostgreSQL<br/>catalog_db)]
    OrderSvc --> OrderDB[(PostgreSQL<br/>order_db)]

    subgraph Message Broker
        MQ[RabbitMQ<br/>:5672]
    end
```

---

## Service Responsibilities

### Auth Service (Node.js + TypeScript)
- User registration และ login
- ออก JWT access token (15 นาที) และ refresh token (7 วัน)
- Revoke refresh token เมื่อ logout
- Expose `/api/auth/verify` endpoint ให้ services อื่นใช้ validate token

### Catalog Service (.NET 10 + C#)
- CRUD Product และ Category
- จัดการ stock quantity
- Consume RabbitMQ events สำหรับ stock deduction/release
- ใช้ Clean Architecture (Controller → Service → Repository)

### Order Service (Node.js + TypeScript)
- รับ order request จาก user
- ตรวจสอบ stock ผ่าน Catalog Service (synchronous HTTP)
- จัดการ order lifecycle (PENDING → CONFIRMED / FAILED)
- Publish events ไปยัง RabbitMQ เพื่อ trigger stock deduction
- ดึง order history ตาม user

### API Gateway (Nginx)
- Single entry point สำหรับทุก request
- Route request ไปยัง service ที่ถูกต้องตาม path prefix
- Terminate TLS (สำหรับ production)
- CORS handling

---

## Communication Flow

### Synchronous (HTTP)
- Frontend → API Gateway → Services
- Order Service → Auth Service (JWT validation)
- Order Service → Catalog Service (stock availability check ก่อน place order)

### Asynchronous (RabbitMQ)
- Order Service → `catalog.stock.deduct` → Catalog Service (เมื่อ order confirmed)
- Order Service → `catalog.stock.release` → Catalog Service (เมื่อ order cancelled)

**เหตุผลที่ใช้ทั้งสองแบบ:** การ check stock ก่อน place order ต้องเป็น synchronous เพื่อ return error ทันทีถ้า stock ไม่พอ แต่การตัด stock จริงทำ asynchronous เพื่อ decouple และรองรับ eventual consistency

---

## Data Ownership

แต่ละ service เป็นเจ้าของ data ของตัวเองอย่างเด็ดขาด ไม่มี service ใดเข้า database ของ service อื่นโดยตรง

| Service | Database | Tables หลัก |
|---|---|---|
| Auth Service | auth_db | users, refresh_tokens |
| Catalog Service | catalog_db | products, categories, stock_adjustments |
| Order Service | order_db | orders, order_items |

---

## Authentication / Authorization Design

### JWT Strategy
- **Access Token**: JWT HS256, หมดอายุ 15 นาที, เก็บใน memory (React state)
- **Refresh Token**: JWT HS256, หมดอายุ 7 วัน, เก็บใน httpOnly cookie
- **Payload**: `{ userId, email, role, iat, exp }`

### Token Validation Flow
1. Client ส่ง `Authorization: Bearer <access_token>`
2. แต่ละ service มี JWT middleware ที่ verify signature โดยใช้ shared secret
3. ไม่มีการ call กลับ Auth Service ทุก request (stateless)
4. Refresh token rotation: ทุกครั้งที่ refresh จะออก refresh token ใหม่และ revoke อันเก่า

### Role-Based Access Control
- Role ถูกฝังใน JWT payload
- Middleware ตรวจสอบ role ก่อนเข้า protected routes
- `ADMIN` role เท่านั้นที่เข้า management endpoints ได้

---

## Order and Stock Flow

```mermaid
sequenceDiagram
    actor User
    participant GW as API Gateway
    participant OS as Order Service
    participant CS as Catalog Service
    participant MQ as RabbitMQ

    User->>GW: POST /api/orders
    GW->>OS: Forward request
    OS->>CS: GET /internal/products/:id/stock
    CS-->>OS: { stockQuantity: 10 }

    alt Stock เพียงพอ
        OS->>OS: สร้าง order (PENDING)
        OS->>MQ: Publish catalog.stock.deduct
        MQ->>CS: Consume event
        CS->>CS: หัก stock
        OS-->>User: 201 Created { orderId }
    else Stock ไม่พอ
        OS-->>User: 400 Bad Request { message: "Insufficient stock" }
    end
```

---

## Trade-offs and Decisions

### 1. แยก Database ต่อ Service
**Decision:** Database-per-service pattern
**เหตุผล:** ทำให้ deploy, scale, และ maintain แต่ละ service ได้อิสระ
**Trade-off:** ไม่มี ACID transaction ข้าม service ต้องใช้ eventual consistency

### 2. ใช้ Nginx เป็น API Gateway
**Decision:** Nginx แทน dedicated API Gateway (Kong, AWS API Gateway)
**เหตุผล:** lightweight, เพียงพอสำหรับ assignment scope, configuration ง่าย
**Trade-off:** ไม่มี built-in rate limiting, circuit breaker, หรือ observability ขั้นสูง

### 3. RabbitMQ สำหรับ Stock Events
**Decision:** Async messaging สำหรับ stock deduction
**เหตุผล:** decouples Order Service จาก Catalog Service, รองรับ retry เมื่อ Catalog Service down
**Trade-off:** เพิ่ม complexity, eventual consistency อาจทำให้ stock แสดงผลล่าช้าชั่วคราว

### 4. Stateless JWT (ไม่มี token blacklist)
**Decision:** Verify JWT ด้วย secret ในแต่ละ service
**เหตุผล:** ไม่ต้องมี central token store, latency ต่ำ
**Trade-off:** ไม่สามารถ revoke access token ได้ทันที ต้องรอหมดอายุ (15 นาที)

---

## Scalability

- แต่ละ service สามารถ scale independently ได้ผ่าน Docker replicas
- Nginx load balance ระหว่าง instances
- RabbitMQ รองรับ competing consumers สำหรับ Catalog Service

## Maintainability

- Catalog Service ใช้ Clean Architecture แยก layer ชัดเจน
- Auth และ Order Service ใช้ layered architecture (Controller → Service → Repository)
- TypeScript strict mode บังคับ type safety
- Environment variables ทั้งหมดไม่ hardcode ใน code
