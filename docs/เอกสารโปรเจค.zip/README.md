# Distributed Product Management System

> Senior Developer Assignment — Distributed architecture สำหรับจัดการสินค้าและรับคำสั่งซื้อ

---

## Overview

ระบบนี้เป็น distributed system ที่ประกอบด้วย 3 microservices หลัก ได้แก่ Auth Service, Catalog Service (.NET), และ Order Service (TypeScript/Node.js) พร้อม React frontend ระบบรองรับการจัดการสินค้า หมวดหมู่ สต็อก และวงจรชีวิตของคำสั่งซื้อแบบ end-to-end

---

## Assignment Context

| รายการ | รายละเอียด |
|---|---|
| โจทย์ | Senior Developer Assignment: Distributed Product Management System |
| ระยะเวลา | 7 วัน |
| Deliverable | Git repository + README + Architecture docs |

---

## Key Features

- **Authentication & Authorization**: Register, Login, Logout พร้อม JWT-based token strategy และ role-based access control (Admin / User)
- **Catalog Management**: CRUD สินค้าและหมวดหมู่, จัดการ stock
- **Order Lifecycle**: สั่งซื้อสินค้า, ตัด stock อัตโนมัติ, ดู order history
- **Frontend SPA**: React application ที่ใช้งานได้จริง

---

## Architecture Overview

```
┌─────────────┐    ┌──────────────────────────────────────────────┐
│   Browser   │───▶│              API Gateway (Nginx)              │
│  (React SPA)│    └───────────┬──────────┬──────────┬────────────┘
└─────────────┘                │          │          │
                               ▼          ▼          ▼
                        ┌──────────┐ ┌─────────┐ ┌──────────┐
                        │  Auth    │ │ Catalog │ │  Order   │
                        │ Service  │ │ Service │ │ Service  │
                        │(Node.js) │ │ (.NET)  │ │  (Node)  │
                        └────┬─────┘ └────┬────┘ └────┬─────┘
                             │            │            │
                        ┌────▼─────┐ ┌────▼────┐ ┌────▼─────┐
                        │ Postgres │ │Postgres │ │ Postgres │
                        │  (auth)  │ │(catalog)│ │ (orders) │
                        └──────────┘ └─────────┘ └──────────┘
                                          │              │
                                     ┌────▼──────────────▼────┐
                                     │        RabbitMQ         │
                                     │  (Stock Reservation)    │
                                     └─────────────────────────┘
```

---

## System Components

| Component | Language / Tech | Port | หน้าที่ |
|---|---|---|---|
| **Auth Service** | Node.js / TypeScript | 3001 | Identity & Access Management |
| **Catalog Service** | .NET 10 / C# | 3002 | Product, Category, Stock |
| **Order Service** | Node.js / TypeScript | 3003 | Order Lifecycle |
| **API Gateway** | Nginx | 8080 | Reverse Proxy / Routing |
| **Frontend** | React / TypeScript | 5173 | SPA |
| **PostgreSQL (auth)** | PostgreSQL 16 | 5432 | Auth database |
| **PostgreSQL (catalog)** | PostgreSQL 16 | 5433 | Catalog database |
| **PostgreSQL (orders)** | PostgreSQL 16 | 5434 | Order database |
| **RabbitMQ** | RabbitMQ 3.x | 5672 / 15672 | Message broker |

---

## Tech Stack

**Backend:**
- Auth Service: Node.js + TypeScript + Express + Prisma ORM
- Catalog Service: .NET 10 + C# + Entity Framework Core
- Order Service: Node.js + TypeScript + Express + Prisma ORM

**Frontend:**
- React + TypeScript + Vite
- Axios สำหรับ HTTP calls
- React Router v6

**Infrastructure:**
- Docker + Docker Compose
- Nginx (API Gateway)
- PostgreSQL 16 (แยก database ต่อ service)
- RabbitMQ (inter-service messaging)

---

## Folder Structure

```
distributed-product-management/
├── apps/
│   ├── auth-service/          # Node.js Auth Service
│   ├── catalog-service/       # .NET Catalog Service
│   └── order-service/         # Node.js Order Service
├── UI1/                       # React Frontend (SPA)
├── infra/
│   ├── docker-compose.yml     # Full stack orchestration
│   ├── nginx/
│   │   └── nginx.conf         # API Gateway config
│   └── migrations/            # DB migration scripts
├── docs/
│   ├── ARCHITECTURE.md
│   ├── API.md
│   ├── ORDER_STOCK_FLOW.md
│   ├── SECURITY.md
│   ├── RUNBOOK.md
│   └── EVALUATION.md
├── .gitignore
└── README.md
```

---

## Prerequisites

- Docker >= 24.0
- Docker Compose >= 2.0
- Node.js >= 20 (สำหรับ local development)
- .NET SDK 10 (สำหรับ local development ของ Catalog Service)

---

## Environment Variables

### Auth Service (`apps/auth-service/.env`)

```env
PORT=3001
DATABASE_URL=postgresql://postgres:password@localhost:5432/auth_db
JWT_ACCESS_SECRET=your-access-secret-key
JWT_REFRESH_SECRET=your-refresh-secret-key
JWT_ACCESS_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=7d
```

### Catalog Service (`apps/catalog-service/appsettings.json`)

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Host=localhost;Port=5433;Database=catalog_db;Username=postgres;Password=password"
  },
  "RabbitMQ": {
    "Host": "localhost",
    "Port": 5672,
    "Username": "guest",
    "Password": "guest"
  }
}
```

### Order Service (`apps/order-service/.env`)

```env
PORT=3003
DATABASE_URL=postgresql://postgres:password@localhost:5434/order_db
RABBITMQ_URL=amqp://guest:guest@localhost:5672
CATALOG_SERVICE_URL=http://localhost:3002
AUTH_SERVICE_URL=http://localhost:3001
JWT_ACCESS_SECRET=your-access-secret-key
```

---

## วิธี Run ด้วย Docker Compose (แนะนำ)

```bash
# 1. Clone repository
git clone https://github.com/SirichaiP/distributed-product-management.git
cd distributed-product-management

# 2. Copy environment files (ถ้ามี .env.example)
cp apps/auth-service/.env.example apps/auth-service/.env
cp apps/order-service/.env.example apps/order-service/.env

# 3. Start ทุก service
cd infra
docker compose up --build

# 4. รอให้ทุก service healthy แล้วเข้าใช้งาน
# Frontend:  http://localhost:5173
# API Gateway: http://localhost:8080
# RabbitMQ Management: http://localhost:15672 (guest/guest)
```

---

## วิธี Run Locally (Development)

### 1. Start Infrastructure

```bash
cd infra
docker compose up postgres-auth postgres-catalog postgres-order rabbitmq -d
```

### 2. Auth Service

```bash
cd apps/auth-service
npm install
npx prisma migrate deploy
npm run dev
# Running on http://localhost:3001
```

### 3. Catalog Service

```bash
cd apps/catalog-service
dotnet restore
dotnet ef database update
dotnet run
# Running on http://localhost:3002
```

### 4. Order Service

```bash
cd apps/order-service
npm install
npx prisma migrate deploy
npm run dev
# Running on http://localhost:3003
```

### 5. Frontend

```bash
cd UI1
npm install
npm run dev
# Running on http://localhost:5173
```

---

## Service URLs

| Service | URL | Swagger |
|---|---|---|
| Frontend | http://localhost:5173 | — |
| API Gateway | http://localhost:8080 | — |
| Auth Service | http://localhost:3001 | http://localhost:3001/api-docs |
| Catalog Service | http://localhost:3002 | http://localhost:3002/swagger |
| Order Service | http://localhost:3003 | http://localhost:3003/api-docs |
| RabbitMQ UI | http://localhost:15672 | — |

---

## Authentication Flow

```
1. POST /api/auth/register  → สร้าง user ใหม่ (role: USER)
2. POST /api/auth/login     → รับ access_token (15m) + refresh_token (7d)
3. ใส่ Authorization: Bearer <access_token> ใน request header
4. POST /api/auth/refresh   → ต่ออายุ access_token
5. POST /api/auth/logout    → revoke refresh_token
```

---

## Role-Based Authorization

| Role | สิทธิ์ |
|---|---|
| `ADMIN` | CRUD product, category, stock adjustment, ดู orders ทั้งหมด |
| `USER` | ดู product, สั่งซื้อ, ดู order ของตัวเอง |

---

## Catalog Flow

```
ADMIN:
  POST   /api/catalog/categories          → สร้าง category
  PUT    /api/catalog/categories/:id      → แก้ไข category
  DELETE /api/catalog/categories/:id      → ลบ category
  POST   /api/catalog/products            → สร้าง product
  PUT    /api/catalog/products/:id        → แก้ไข product
  DELETE /api/catalog/products/:id        → ลบ product
  PATCH  /api/catalog/products/:id/stock  → ปรับ stock

USER/PUBLIC:
  GET    /api/catalog/products            → ดู product list
  GET    /api/catalog/products/:id        → ดู product detail
  GET    /api/catalog/categories          → ดู category list
```

---

## Order Flow

```
1. USER เรียก POST /api/orders พร้อม items[]
2. Order Service ตรวจสอบ stock ผ่าน Catalog Service (HTTP หรือ RabbitMQ)
3. ถ้า stock เพียงพอ → reserve stock → สร้าง order (status: PENDING)
4. Order confirm → ตัด stock จริง → status: CONFIRMED
5. ถ้า stock ไม่พอ → return 400 Bad Request
```

---

## Stock Reservation / Adjustment Flow

```
Stock Deduction (เมื่อ order สำเร็จ):
  Order Service publish event → catalog.stock.deduct
  Catalog Service consume → หัก stock จาก DB

Stock Release (เมื่อ order ยกเลิก):
  Order Service publish event → catalog.stock.release
  Catalog Service consume → คืน stock

Admin Stock Adjustment:
  PATCH /api/catalog/products/:id/stock { quantity: 50, type: "ADD" | "SUBTRACT" }
```

---

## Important API Endpoints

### Auth

```
POST /api/auth/register
POST /api/auth/login
POST /api/auth/logout
POST /api/auth/refresh
GET  /api/auth/me
```

### Catalog

```
GET    /api/catalog/products
POST   /api/catalog/products          [ADMIN]
PUT    /api/catalog/products/:id      [ADMIN]
DELETE /api/catalog/products/:id      [ADMIN]
PATCH  /api/catalog/products/:id/stock [ADMIN]
GET    /api/catalog/categories
POST   /api/catalog/categories        [ADMIN]
```

### Orders

```
POST /api/orders                      [USER]
GET  /api/orders/me                   [USER]
GET  /api/orders/:id                  [USER/ADMIN]
GET  /api/orders                      [ADMIN]
```

---

## Frontend Pages

| หน้า | เส้นทาง | การเข้าถึง |
|---|---|---|
| หน้าแรก / Product List | `/` | Public |
| Login | `/login` | Public |
| Register | `/register` | Public |
| Product Detail | `/products/:id` | Public |
| Cart / Checkout | `/cart` | USER |
| My Orders | `/orders` | USER |
| Admin Dashboard | `/admin` | ADMIN |
| Admin Products | `/admin/products` | ADMIN |
| Admin Categories | `/admin/categories` | ADMIN |
| Admin Orders | `/admin/orders` | ADMIN |

---

## Demo User Accounts

| Email | Password | Role |
|---|---|---|
| admin@example.com | Admin1234! | ADMIN |
| user@example.com | User1234! | USER |

---

## Testing Instructions

```bash
# Auth Service unit tests
cd apps/auth-service
npm run test

# Catalog Service unit tests
cd apps/catalog-service
dotnet test

# Order Service unit tests
cd apps/order-service
npm run test

# Integration tests (ต้องมี Docker running)
npm run test:integration
```

---

## Troubleshooting

ดู [docs/RUNBOOK.md](docs/RUNBOOK.md) สำหรับรายละเอียด

**Port conflicts:** ตรวจสอบว่า port 3001–3003, 5173, 8080, 5432–5434, 5672, 15672 ว่างอยู่

**Database connection:** `docker compose logs postgres-catalog` เพื่อดู log

**RabbitMQ:** เข้า http://localhost:15672 (guest/guest) เพื่อตรวจสอบ queue

---

## Known Limitations

- ไม่มี distributed transaction (Saga pattern) — ใช้ eventual consistency ผ่าน RabbitMQ
- ไม่มี circuit breaker pattern (Polly/resilience4j)
- ไม่มี monitoring stack (Prometheus/Grafana)
- Frontend ไม่มี real-time stock update (WebSocket)

---

## Future Improvements

- เพิ่ม Saga Orchestrator สำหรับ complex order flow
- เพิ่ม Distributed Tracing (OpenTelemetry + Jaeger)
- เพิ่ม Redis สำหรับ token blacklist และ cache
- เพิ่ม CI/CD pipeline (GitHub Actions)
- เพิ่ม rate limiting ที่ API Gateway

---

## Evaluation Mapping

| หัวข้อ | น้ำหนัก | หลักฐาน |
|---|---|---|
| System design & architectural decisions | 25 | `docs/ARCHITECTURE.md`, Docker Compose, API Gateway config |
| Service boundaries & inter-service communication | 20 | RabbitMQ events, HTTP inter-service calls |
| Security & identity design | 15 | JWT strategy, RBAC middleware, `docs/SECURITY.md` |
| Code quality (backend + frontend) | 15 | TypeScript strict mode, C# Clean Architecture, validation |
| Functional completeness | 10 | Feature coverage ครบทุก business requirement |
| Resilience, testing, observability | 10 | Unit tests, health checks, structured logging |
| Documentation & Git hygiene | 5 | README, docs/, meaningful commit history |

---

## Author

**Sirichai P.**
Senior Developer Assignment Submission
