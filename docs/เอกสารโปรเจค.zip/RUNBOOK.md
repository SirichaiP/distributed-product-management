# Runbook

## วิธี Start Services

### ทุก Services (Docker Compose — แนะนำ)

```bash
cd infra
docker compose up --build
```

**รอให้เห็น log ต่อไปนี้ก่อนใช้งาน:**
```
auth-service     | Server listening on port 3001
catalog-service  | Now listening on http://[::]:3002
order-service    | Server listening on port 3003
nginx            | start worker processes
```

### เฉพาะ Infrastructure (Database + RabbitMQ)

```bash
cd infra
docker compose up postgres-auth postgres-catalog postgres-order rabbitmq -d
```

---

## วิธี Stop Services

```bash
# หยุดทุก service แต่เก็บ volume (data ยังอยู่)
docker compose stop

# หยุดและลบ container (data ยังอยู่)
docker compose down

# หยุดและลบทุกอย่างรวม volume (data หาย)
docker compose down -v
```

---

## Service URLs

| Service | URL |
|---|---|
| Frontend | http://localhost:5173 |
| API Gateway | http://localhost:8080 |
| Auth Service (direct) | http://localhost:3001 |
| Auth Swagger | http://localhost:3001/api-docs |
| Catalog Service (direct) | http://localhost:3002 |
| Catalog Swagger | http://localhost:3002/swagger |
| Order Service (direct) | http://localhost:3003 |
| Order Swagger | http://localhost:3003/api-docs |
| RabbitMQ Management UI | http://localhost:15672 |

RabbitMQ credentials: `guest` / `guest`

---

## Health Check URLs

```bash
curl http://localhost:3001/health
curl http://localhost:3002/health
curl http://localhost:3003/health
```

Expected response: `{ "status": "ok", "timestamp": "..." }`

---

## Common Errors

### Port Already in Use

```bash
# ตรวจสอบว่า port ไหนถูกใช้อยู่
lsof -i :3001
lsof -i :8080

# Kill process นั้น
kill -9 <PID>
```

หรือแก้ไข port ใน `infra/docker-compose.yml`

---

### Database Connection Failed

**อาการ:** Service log แสดง `ECONNREFUSED` หรือ `Connection refused`

**แก้ไข:**

```bash
# ตรวจสอบว่า database container ทำงานอยู่
docker compose ps

# ดู log ของ postgres
docker compose logs postgres-catalog

# รอ database พร้อม แล้ว restart service
docker compose restart catalog-service
```

---

### RabbitMQ Connection Failed

**อาการ:** `AMQP Connection error` ใน log ของ Order Service หรือ Catalog Service

**แก้ไข:**

```bash
# ตรวจสอบ RabbitMQ
docker compose logs rabbitmq

# ตรวจสอบ queue ผ่าน UI
open http://localhost:15672

# Restart services หลัง RabbitMQ พร้อม
docker compose restart order-service catalog-service
```

---

### Frontend ไม่เชื่อมต่อ API

**อาการ:** `Network Error` หรือ `CORS error` ใน browser console

**แก้ไข:**

1. ตรวจสอบว่า API Gateway (port 8080) ทำงานอยู่
2. ตรวจสอบ `VITE_API_URL` ใน `UI1/.env`
3. ล้าง browser cache แล้วลอง refresh

---

### Database Migration Failed

```bash
# Auth Service
cd apps/auth-service
npx prisma migrate reset  # Warning: ลบ data ทั้งหมด
npx prisma migrate deploy

# Catalog Service
cd apps/catalog-service
dotnet ef database drop --force
dotnet ef database update

# Order Service
cd apps/order-service
npx prisma migrate reset
npx prisma migrate deploy
```

---

### JWT Token Expired

**อาการ:** API return `401 Unauthorized` พร้อม `{ "error": "Token expired" }`

**แก้ไข:** Frontend ควร handle โดยอัตโนมัติโดย call `POST /api/auth/refresh` แล้ว retry request เดิม

---

## Logs

```bash
# ดู log ทุก service
docker compose logs -f

# ดู log เฉพาะ service
docker compose logs -f auth-service
docker compose logs -f catalog-service
docker compose logs -f order-service

# ดู log 100 บรรทัดล่าสุด
docker compose logs --tail=100 order-service
```

---

## Database Access

```bash
# เข้า Catalog DB
docker compose exec postgres-catalog psql -U postgres -d catalog_db

# Query ดู products
SELECT id, name, stock_quantity FROM products LIMIT 10;

# Query ดู stock adjustments
SELECT * FROM stock_adjustments ORDER BY created_at DESC LIMIT 10;
```

---

## Reset ทุกอย่าง (Clean Start)

```bash
cd infra
docker compose down -v          # ลบ container และ volume ทั้งหมด
docker compose up --build       # Build และ start ใหม่
```

**คำเตือน:** ข้อมูลทั้งหมดจะถูกลบ
